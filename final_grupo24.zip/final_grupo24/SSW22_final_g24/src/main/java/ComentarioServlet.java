/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import Containers.Comentario;
import Model.*;
import Containers.User;
import Model.UserDB;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author alons
 */
@WebServlet(urlPatterns = {"/ComentarioServlet"})
public class ComentarioServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ComentarioServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ComentarioServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String divisaAnterior = request.getParameter("divisaAnterior");
        String divisa = request.getParameter("select");
        session.setAttribute("divisa", divisa);
        String comentario = request.getParameter("comentario");
        String id = (String) session.getAttribute("id");
        
        if(divisaAnterior.equals("Euro") && divisa.equals("Libra")){
                MovimientoDB.updateEurosLibra(id);
                claseAhorroDB.updateEurosLibra(id);
                UserDB.updateEurosLibra(id);
        }else if(divisaAnterior.equals("Libra") && divisa.equals("Euro")){
                MovimientoDB.updateLibraEuros(id);
                claseAhorroDB.updateLibraEuros(id);
                UserDB.updateLibraEuros(id);

        }else if(divisaAnterior.equals("Euro") && divisa.equals("Dolar")){
                MovimientoDB.updateEurosDolar(id);
                claseAhorroDB.updateEurosDolar(id);
                UserDB.updateEurosDolar(id);

        }else if(divisaAnterior.equals("Dolar") && divisa.equals("Euro")){
                MovimientoDB.updateDolarEuros(id);
                claseAhorroDB.updateDolarEuros(id);
                UserDB.updateDolarEuros(id);

        }else if(divisaAnterior.equals("Libra") && divisa.equals("Dolar")){
                MovimientoDB.updateLibraDolar(id);
                claseAhorroDB.updateLibraDolar(id);
                UserDB.updateLibraDolar(id);

        }else if(divisaAnterior.equals("Dolar") && divisa.equals("Libra")){
                MovimientoDB.updateDolarLibra(id);
                claseAhorroDB.updateDolarLibra(id);
                UserDB.updateDolarLibra(id);


        }
        
        User usuario = new User();
        
        System.out.println("El comentario es: "+comentario);
            
        usuario.setDivisa(divisa);
   
        
        try {
            
            UserDB.updateDivisa(usuario, id);
            
            if(comentario.isEmpty()){
                System.out.println("Esta vacio el coment");
            }else{
                System.out.println("Se crean cositis");
                Comentario comment = new Comentario();
                comment.setComentario(comentario);
                comment.setFecha(fechaFormateada());
                comment.setIdUsuario(id);
                ComentarioDB.nuevoComentario(comment);
            }
        } catch (Exception ex) {
            Logger.getLogger(ModificarUsuarioServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        ResultSet resultSet = UserDB.sacaUsuarioRS((String)request.getSession().getAttribute("id"));
        request.getSession().setAttribute("usuarioResumen", resultSet);

        ResultSet resultSet2 = MovimientoDB.selectMovimientosResumen((String)request.getSession().getAttribute("id"));
        request.getSession().setAttribute("movimientosResumen", resultSet2);
            
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/resumen.jsp");
        dispatcher.forward(request, response);
    }
    
    private String fechaFormateada(){
        Calendar cl = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(cl.getTime());
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

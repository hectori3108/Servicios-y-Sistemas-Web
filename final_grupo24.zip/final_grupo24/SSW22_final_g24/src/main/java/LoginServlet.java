/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Model.ConnectionPool;
import Model.MovimientoDB;
import Model.UserDB;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author carlo
 */
@WebServlet(urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet LoginServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet LoginServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String usu=request.getParameter("user");
        String usu2 = request.getParameter("password");
        
        String url = "/resumen.jsp";
        
        try {
            if (UserDB.emailExists(usu) && UserDB.userExists(usu, usu2)) {
                 url = "/resumen.jsp";
                 HttpSession session = request.getSession();
                 session.setAttribute("user", usu);
                 Statement sta = null;
                 ResultSet cod2 = null;
                 
                 ConnectionPool pool = ConnectionPool.getInstance();
                 Connection cnx = pool.getConnection();
        
                 sta=cnx.createStatement();
                 cod2 = sta.executeQuery("select id from usuario where email='"+usu+"'");
                 cod2.next();
                 String id = "" + cod2.getInt(1);
                 ResultSet resultSet = UserDB.sacaUsuarioRS(id);
                 request.getSession().setAttribute("usuarioResumen", resultSet);
                 ResultSet resultSet2 = MovimientoDB.selectMovimientosResumen(id);
                 request.getSession().setAttribute("movimientosResumen", resultSet2);

                 ResultSet divisa = sta.executeQuery("select divisa from usuario where id='"+id+"'");
                 divisa.next();
                 
                 System.out.println("Lo del servlet " + (String)divisa.getString(1));
                 session.setAttribute("id", id);
                 session.setAttribute("divisa", divisa.getString(1));
            } else {
                url = "/login2.html";
            }
        } catch (Exception ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
       
            RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
            dispatcher.forward(request, response);
        
        
    }
    

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
